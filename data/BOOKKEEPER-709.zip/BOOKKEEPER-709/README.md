# Flaky Test Datset

This repository contains timing-dependent flaky unit test, its developer fix, enhanced test failure with code changes, and the corresponding code changes applied to the fixed version. It also includes all the necessary scripts to execute the test across different code versions. The test is designed to run within a Docker container, with the results being copied to the result directory on the host machine.

## Prerequisites

- **Docker**: Ensure Docker is installed and running on your system to enable containerized execution of the analysis.
- **Linux (Tested on Version 22)**: The analysis has been tested on Linux 22 and is recommended for optimal performance.  
  - **Mac Compatibility**: The setup should be compatible with macOS as well. If you encounter any issues on macOS, please let us know.




### `Input`

To execute the script, run the `run_flakytool.sh` script. This will launch the container with default parameters, but you can customize the parameters to suit your requirements.

#### Parameters for `flaky_analysis_tool.sh`
- **`moduleName`**:  
  The relative path of the module from the root directory.  
  Example: `bookkeeper-server`.

- **`fullQualifiedTest`**:  
  The fully qualified name of the test method.  
  Example: `org.apache.bookkeeper.client.SlowBookieTest#testSlowBookie`.

- **`iteration`**:  
  The number of test iterations to run. Default is `100`, but you can adjust this based on your requirements. 

- **`version_code (Optional)`**:  
  Specifies the code version to analyze. If you don't send any version code, then it will run for All. Allowed values include:
  - `All`
  - `Flaky`
  - `FlakyCodeChange`
  - `Fixed`
  - `FixedCodeChange`.

- **`script_url (Optional)`**:  
  The GitHub repository URL containing the analysis scripts. You can change the script and provide your customized script.
  Base Url: [https://github.com/mahbubsumon085/flaky-data-parsing-tools.git](https://github.com/mahbubsumon085/flaky-data-parsing-tools.git)

- **`commit_hash(Optional)`**:  
  The commit hash of the script to use. You can use the default hash provided or specify a custom one.  
  Default: `63586db0ed4b911f7d0981d077ed29f5601729b3`.

## Output
After executing the script, the following outputs will be generated and stored in the `result` directory on the host machine. The results are organized into subdirectories based on the version codes: `Flaky`, `FlakyCodeChange`, `Fixed`, and `FixedCodeChange`.

- **surefire-reports**:  
  Maven-generated reports containing detailed test execution logs. These include information about passed, failed, and errored test cases, along with stack traces and other debugging details.

- **rounds-test-results.csv**:  
  A CSV file summarizing the outcomes of all test iterations. It provides whether the test passes, failures, or has errors.

- **testlog**:  
  Log file capturing the output from each iteration as it appears in the terminal during test execution.

- **summary.txt**:  
  A text file summarizing key test metrics, such as total iterations, passes, failures, and errors.


## Important Folder and Files

The following are the key folder and files and used during the execution of the flaky test analysis:

- **`Flaky`**:  
  Contains the source code that includes the flaky test. 

- **`Fixed.patch`**:  
  A patch file used to generate the fixed version of the source code from the `Flaky` folder. Used by **`flaky_analysis_tool.sh`** during execution.

- **`FixedCodeChange.patch`**:  
  A patch file used to generate the fixed version with additional code changes from the `Flaky` folder. Used by **`flaky_analysis_tool.sh`** during execution.

- **`FlakyCodeChange.patch`**:  
  A patch file used to generate the flaky version with additional code changes from the `Flaky` folder. This patch is applied by **`flaky_analysis_tool.sh`** during execution to prepare the required source for analysis.


- **`Dockerfile`**:  
  A configuration file for building the Docker image used in flaky test analysis. It sets up a Java 8 and Maven environment, installs required dependencies (e.g., Protobuf tools, Python, BeautifulSoup, lxml), and defines a default command to run the `statistics_generator.sh` script, which is retrieved from the script repository. 

- **`flaky_analysis_tool.sh`**:  
  A comprehensive script designed to execute and manage the analysis of a single flaky test across various code versions within a Docker container. It performs the following functions:
  - Parses input parameters such as module name, test name, iteration count, code version, script URL, and commit hash.
  - Clones and applies patch files to generate corresponding source directories (`Flaky`, `FlakyCodeChange`, `Fixed`, and `FixedCodeChange`).
  - Builds a Docker image and runs a containerized environment for the test execution.
  - Copies necessary source and `.m2` directories into the container.
  - Executes the statistics generator script inside the container for iterative test analysis.
  - Collects and organizes test results into a structured `result` directory.
  - Cleans up temporary containers and directories to maintain a tidy workspace.

- **`run_flakytool.sh`**:  
  A wrapper script that simplifies running `flaky_analysis_tool.sh` by providing predefined or customizable parameters, including the module name, test name, iteration count, code version, script URL, and commit hash. Users can also avoid using this script by directly running the `flaky_analysis_tool.sh` command from their terminal with the required parameters.

- **`Flakym2`**:  
  A directory used to store the `.m2` repository for Maven dependencies during test execution. This ensures that the containerized environment can access required dependencies efficiently without re-downloading them for each run.

- **`Fixedm2`**:  
  A directory used to store the `.m2` repository for Maven dependencies specific to the fixed version. If the dependencies for the fixed version are the same as those in `Flakym2`, this directory will not be present in the data directory, as `Flakym2` can handle Maven execution requirements.



### Example Usage

To analyze the flaky test `SlowBookieTest#testSlowBookie` in the `bookkeeper-server` module with 100 iterations for the version code `Flaky`, using the provided script URL and commit hash:

```bash
chmod +x flaky_analysis_tool.sh
./flaky_analysis_tool.sh bookkeeper-server org.apache.bookkeeper.client.SlowBookieTest#testSlowBookie 100 Flaky https://github.com/mahbubsumon085/flaky-data-parsing-tools.git 63586db0ed4b911f7d0981d077ed29f5601729b3
