for i in {1..20}
   do
      mvn -pl bookkeeper-server  test -Dtest=org.apache.bookkeeper.client.SlowBookieTest#testSlowBookie
done
